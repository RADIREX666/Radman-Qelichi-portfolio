const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const isLowPowerDevice =
  (Number(navigator.hardwareConcurrency) > 0 && Number(navigator.hardwareConcurrency) <= 4) ||
  (Number(navigator.deviceMemory) > 0 && Number(navigator.deviceMemory) <= 4);

const SEND_ICON =
  '<span class="iconify icon-glyph" aria-hidden="true"><svg viewBox="0 0 24 24" width="1em" height="1em" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12 20 4l-4 16-4-6-8-2Z"/><path d="m12 14 8-10"/></svg></span>';
const CALL_SENT_ICON =
  '<span class="iconify icon-glyph" aria-hidden="true"><svg viewBox="0 0 24 24" width="1em" height="1em" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/></svg></span>';

document.addEventListener("DOMContentLoaded", () => {
  if (isLowPowerDevice) {
    document.documentElement.classList.add("reduced-effects");
  }

  setupThemeToggle();
  setupScrollBehavior();
  setupMobileMenu();
  setupActiveNavLinks();
  setupContactForm();
  setupBookCallButton();
  setupTypedEffect();
  setupAnalyticsTracking();
  setupWebVitalsReporting();

  runWhenIdle(() => {
    setupSectionReveal();
    setupCounters();
  });
});

function runWhenIdle(callback) {
  if ("requestIdleCallback" in window) {
    window.requestIdleCallback(callback, { timeout: 400 });
    return;
  }

  window.setTimeout(callback, 1);
}

function trackEvent(eventName, props = {}) {
  if (typeof window.plausible === "function") {
    window.plausible(eventName, { props });
  }

  if (typeof window.gtag === "function") {
    window.gtag("event", eventName, props);
  }
}

function setupAnalyticsTracking() {
  const trackedElements = document.querySelectorAll("[data-track]");

  trackedElements.forEach((element) => {
    element.addEventListener("click", () => {
      trackEvent(String(element.getAttribute("data-track") || "ui_click"), {
        href: String(element.getAttribute("href") || ""),
        text: String(element.textContent || "").trim().slice(0, 80),
      });
    });
  });

  document.querySelectorAll("a[href]").forEach((link) => {
    const href = link.getAttribute("href") || "";
    if (!href.startsWith("http")) {
      return;
    }

    let isExternal = false;
    try {
      isExternal = new URL(href).origin !== window.location.origin;
    } catch (_error) {
      return;
    }

    if (!isExternal) {
      return;
    }

    link.addEventListener("click", () => {
      trackEvent("outbound_link_click", {
        href,
      });
    });
  });
}

function setupBookCallButton() {
  const bookCallButton = document.querySelector('[data-track="cta_book_call"]');

  if (!bookCallButton) {
    return;
  }

  const defaultLabel = (bookCallButton.textContent || "Book a Call").trim();
  let isSent = false;
  const setLoadingState = (isLoading) => {
    bookCallButton.classList.toggle("is-sent", false);
    bookCallButton.classList.toggle("is-loading", isLoading);
    bookCallButton.disabled = isLoading;
    bookCallButton.setAttribute("aria-disabled", isLoading ? "true" : "false");
    bookCallButton.setAttribute("aria-busy", isLoading ? "true" : "false");
    bookCallButton.innerHTML = isLoading
      ? '<span class="loading-spinner" aria-hidden="true"></span>Sending...'
      : defaultLabel;
  };
  const setSentState = () => {
    isSent = true;
    bookCallButton.disabled = true;
    bookCallButton.classList.remove("is-loading");
    bookCallButton.classList.add("is-sent");
    bookCallButton.setAttribute("aria-disabled", "true");
    bookCallButton.setAttribute("aria-busy", "false");
    bookCallButton.innerHTML = `${CALL_SENT_ICON}Sent`;
  };

  bookCallButton.addEventListener("click", async (event) => {
    event.preventDefault();
    if (bookCallButton.disabled) {
      return;
    }
    setLoadingState(true);

    try {
      const response = await fetch("/api/contact.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          name: "Website Visitor",
          email: "radirex-call@radirex.ir",
          subject: "Book a call request",
          message: "A visitor clicked the Book a Call button and requested a call.",
          company: "",
        }),
      });

      let data = null;
      try {
        data = await response.json();
      } catch (_error) {
        data = null;
      }

      if (!response.ok || !data || data.ok !== true) {
        throw new Error("book_call_failed");
      }

      showSiteNotification("Call request sent to radmanqelichi@gmail.com", "success");
      trackEvent("book_call_request", { status: "success" });
      setSentState();
      await new Promise((resolve) => {
        window.setTimeout(resolve, 1000);
      });
    } catch (_error) {
      showSiteNotification("Could not send request now. Please email radmanqelichi@gmail.com", "error");
      trackEvent("book_call_request", { status: "failed" });
    } finally {
      if (!isSent) {
        setLoadingState(false);
      }
    }
  });
}

function setupWebVitalsReporting() {
  if (!("PerformanceObserver" in window)) {
    return;
  }

  let clsValue = 0;
  let lcpValue = 0;
  let inpValue = 0;
  let hasReported = false;

  const reportMetric = (name, value) => {
    if (!Number.isFinite(value) || value <= 0) {
      return;
    }

    const rounded = Number(value.toFixed(2));
    let rating = "good";
    if (name === "LCP" && rounded > 2500) {
      rating = "needs-improvement";
    } else if (name === "CLS" && rounded > 0.1) {
      rating = "needs-improvement";
    } else if (name === "INP" && rounded > 200) {
      rating = "needs-improvement";
    }

    trackEvent("web_vital", { metric: name, value: rounded, rating });
  };

  try {
    const lcpObserver = new PerformanceObserver((entryList) => {
      const entries = entryList.getEntries();
      const lastEntry = entries[entries.length - 1];
      if (lastEntry) {
        lcpValue = lastEntry.startTime;
      }
    });
    lcpObserver.observe({ type: "largest-contentful-paint", buffered: true });
  } catch (_error) {
    // Older browsers may not support this entry type.
  }

  try {
    const clsObserver = new PerformanceObserver((entryList) => {
      entryList.getEntries().forEach((entry) => {
        if (!entry.hadRecentInput) {
          clsValue += entry.value;
        }
      });
    });
    clsObserver.observe({ type: "layout-shift", buffered: true });
  } catch (_error) {
    // Older browsers may not support this entry type.
  }

  try {
    const inpObserver = new PerformanceObserver((entryList) => {
      entryList.getEntries().forEach((entry) => {
        if (entry.interactionId && entry.duration > inpValue) {
          inpValue = entry.duration;
        }
      });
    });
    inpObserver.observe({ type: "event", durationThreshold: 40, buffered: true });
  } catch (_error) {
    // Older browsers may not support this entry type.
  }

  const flushMetrics = () => {
    if (hasReported) {
      return;
    }
    hasReported = true;
    reportMetric("LCP", lcpValue);
    reportMetric("CLS", clsValue);
    reportMetric("INP", inpValue);
  };

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      flushMetrics();
    }
  });
  window.addEventListener("pagehide", flushMetrics, { once: true });
}

function showSiteNotification(message, kind) {
  const notificationId = "siteNotification";
  let notification = document.getElementById(notificationId);

  if (!notification) {
    notification = document.createElement("div");
    notification.id = notificationId;
    notification.className = "site-notice";
    notification.setAttribute("role", "status");
    notification.setAttribute("aria-live", "polite");
    document.body.appendChild(notification);
  }

  notification.textContent = message;
  notification.classList.remove("is-error", "is-success");
  notification.classList.add(kind === "error" ? "is-error" : "is-success", "is-visible");

  if (notification.hideTimer) {
    window.clearTimeout(notification.hideTimer);
  }

  notification.hideTimer = window.setTimeout(() => {
    notification.classList.remove("is-visible");
  }, 3600);
}

function setupThemeToggle() {
  const themeToggle = document.getElementById("themeToggle");
  const htmlElement = document.documentElement;

  if (!themeToggle) {
    return;
  }

  const updateThemeLabel = () => {
    const currentTheme = htmlElement.getAttribute("data-theme");
    const label = currentTheme === "light" ? "Switch to dark mode" : "Switch to light mode";
    themeToggle.setAttribute("aria-label", label);
    themeToggle.setAttribute("title", label);
  };

  updateThemeLabel();

  themeToggle.addEventListener("click", () => {
    const currentTheme = htmlElement.getAttribute("data-theme");
    const newTheme = currentTheme === "light" ? "dark" : "light";

    htmlElement.setAttribute("data-theme", newTheme);
    localStorage.setItem("theme", newTheme);
    updateThemeLabel();

    trackEvent("theme_toggled", { theme: newTheme });
  });
}

function setupScrollBehavior() {
  const navbar = document.querySelector(".navbar");
  const scrollBtn = document.getElementById("scrollTop");

  let lastKnownScrollY = window.scrollY;
  let isTicking = false;

  const updateScrollUi = () => {
    if (navbar) {
      navbar.classList.toggle("scrolled", lastKnownScrollY > 50);
    }
    if (scrollBtn) {
      scrollBtn.classList.toggle("is-visible", lastKnownScrollY > 500);
    }
  };

  const onScroll = () => {
    lastKnownScrollY = window.scrollY;
    if (isTicking) {
      return;
    }

    isTicking = true;
    window.requestAnimationFrame(() => {
      updateScrollUi();
      isTicking = false;
    });
  };

  window.addEventListener("scroll", onScroll, { passive: true });
  updateScrollUi();

  if (scrollBtn) {
    scrollBtn.addEventListener("click", () => {
      trackEvent("scroll_to_top");
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }
}

function setupMobileMenu() {
  const hamburger = document.getElementById("hamburger");
  const navMenu = document.getElementById("nav-menu");
  const navLinks = navMenu ? navMenu.querySelectorAll(".nav-link") : [];
  const mainContent = document.getElementById("main-content");
  const siteFooter = document.querySelector("footer");
  let previouslyFocusedElement = null;

  if (!hamburger || !navMenu) {
    return;
  }

  const closeMenu = () => {
    navMenu.classList.remove("active");
    hamburger.classList.remove("toggle");
    hamburger.setAttribute("aria-expanded", "false");
    hamburger.setAttribute("aria-label", "Open menu");
    document.body.classList.remove("menu-open");
    if (mainContent) {
      mainContent.removeAttribute("aria-hidden");
    }
    if (siteFooter) {
      siteFooter.removeAttribute("aria-hidden");
    }
    if (previouslyFocusedElement && typeof previouslyFocusedElement.focus === "function") {
      previouslyFocusedElement.focus();
      previouslyFocusedElement = null;
    }
  };

  const openMenu = () => {
    previouslyFocusedElement = document.activeElement;
    navMenu.classList.add("active");
    hamburger.classList.add("toggle");
    hamburger.setAttribute("aria-expanded", "true");
    hamburger.setAttribute("aria-label", "Close menu");
    document.body.classList.add("menu-open");
    if (mainContent) {
      mainContent.setAttribute("aria-hidden", "true");
    }
    if (siteFooter) {
      siteFooter.setAttribute("aria-hidden", "true");
    }

    const focusableItems = getFocusableElements(navMenu);
    if (focusableItems.length) {
      focusableItems[0].focus();
    }
  };

  hamburger.addEventListener("click", () => {
    const isOpen = navMenu.classList.contains("active");
    if (isOpen) {
      closeMenu();
      return;
    }
    openMenu();
  });

  navLinks.forEach((link) => {
    link.addEventListener("click", () => {
      closeMenu();
    });
  });

  document.addEventListener("keydown", (event) => {
    const isMenuOpen = navMenu.classList.contains("active");
    if (!isMenuOpen) {
      return;
    }

    if (event.key === "Escape") {
      closeMenu();
      hamburger.focus();
      return;
    }

    if (event.key !== "Tab") {
      return;
    }

    const focusableItems = getFocusableElements(navMenu);
    if (!focusableItems.length) {
      return;
    }

    const firstItem = focusableItems[0];
    const lastItem = focusableItems[focusableItems.length - 1];

    if (event.shiftKey && document.activeElement === firstItem) {
      event.preventDefault();
      lastItem.focus();
      return;
    }

    if (!event.shiftKey && document.activeElement === lastItem) {
      event.preventDefault();
      firstItem.focus();
    }
  });
}

function getFocusableElements(container) {
  if (!container) {
    return [];
  }

  return Array.from(
    container.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )
  ).filter((element) => !element.hasAttribute("hidden"));
}

function setupActiveNavLinks() {
  const navLinks = document.querySelectorAll(".navbar .nav-link[href^='#']");

  if (!navLinks.length || !("IntersectionObserver" in window)) {
    return;
  }

  const linkBySectionId = new Map();
  navLinks.forEach((link) => {
    const target = link.getAttribute("href");
    if (!target || target.length <= 1) {
      return;
    }
    linkBySectionId.set(target.slice(1), link);
  });

  const sectionObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) {
          return;
        }

        const activeId = entry.target.id;
        navLinks.forEach((link) => {
          const isActive = link.getAttribute("href") === `#${activeId}`;
          link.classList.toggle("active", isActive);
          if (isActive) {
            link.setAttribute("aria-current", "true");
          } else {
            link.removeAttribute("aria-current");
          }
        });
      });
    },
    {
      rootMargin: "-35% 0px -50% 0px",
      threshold: 0.01,
    }
  );

  linkBySectionId.forEach((_link, sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      sectionObserver.observe(section);
    }
  });
}

function setupSectionReveal() {
  const sections = document.querySelectorAll(".fade-in-section");

  if (!sections.length) {
    return;
  }

  if (prefersReducedMotion || !("IntersectionObserver" in window)) {
    sections.forEach((section) => section.classList.add("visible"));
    return;
  }

  const sectionObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) {
          return;
        }

        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      });
    },
    {
      threshold: 0.15,
      rootMargin: "0px 0px -10% 0px",
    }
  );

  sections.forEach((section) => sectionObserver.observe(section));
}

function setupCounters() {
  const counters = document.querySelectorAll(".counter[data-target]");

  if (!counters.length) {
    return;
  }

  if (prefersReducedMotion || !("IntersectionObserver" in window)) {
    counters.forEach((counter) => {
      const target = Number(counter.getAttribute("data-target")) || 0;
      counter.textContent = getCounterValue(counter, target);
    });
    return;
  }

  const counterObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) {
          return;
        }

        animateCounter(entry.target);
        observer.unobserve(entry.target);
      });
    },
    {
      threshold: 0.75,
    }
  );

  counters.forEach((counter) => counterObserver.observe(counter));
}

function animateCounter(counter) {
  const target = Number(counter.getAttribute("data-target")) || 0;
  const durationMs = 1200;
  const start = performance.now();

  const tick = (time) => {
    const progress = Math.min((time - start) / durationMs, 1);
    const eased = 1 - (1 - progress) ** 3;
    const currentValue = Math.round(target * eased);
    counter.textContent = getCounterValue(counter, currentValue);

    if (progress < 1) {
      window.requestAnimationFrame(tick);
    }
  };

  window.requestAnimationFrame(tick);
}

function getCounterValue(counter, value) {
  const prefix = counter.getAttribute("data-prefix") || "";
  const suffix = counter.getAttribute("data-suffix") || "";
  return `${prefix}${value}${suffix}`;
}

function setupContactForm() {
  const contactForm = document.getElementById("contactForm");
  const formMessage = document.getElementById("formMessage");
  const submitButton = document.getElementById("contactSubmit");

  if (!contactForm || !formMessage || !submitButton) {
    return;
  }

  const defaultSubmitLabel = "Send Message";
  const fields = [
    {
      name: "name",
      input: contactForm.querySelector("#name"),
      error: contactForm.querySelector("#nameError"),
      validate(value) {
        if (!value) {
          return "Please enter your name.";
        }
        if (value.length < 2) {
          return "Name should be at least 2 characters.";
        }
        return "";
      },
    },
    {
      name: "email",
      input: contactForm.querySelector("#email"),
      error: contactForm.querySelector("#emailError"),
      validate(value) {
        if (!value) {
          return "Please enter your email address.";
        }
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(value)) {
          return "Please enter a valid email address.";
        }
        return "";
      },
    },
    {
      name: "subject",
      input: contactForm.querySelector("#subject"),
      error: contactForm.querySelector("#subjectError"),
      validate(value) {
        if (!value) {
          return "Please enter a subject.";
        }
        if (value.length < 4) {
          return "Subject should be at least 4 characters.";
        }
        return "";
      },
    },
    {
      name: "message",
      input: contactForm.querySelector("#message"),
      error: contactForm.querySelector("#messageError"),
      validate(value) {
        if (!value) {
          return "Please share a quick message.";
        }
        if (value.length < 12) {
          return "Message should be at least 12 characters.";
        }
        return "";
      },
    },
  ].filter((field) => field.input && field.error);

  const setSubmitButtonState = (isLoading) => {
    submitButton.disabled = isLoading;
    submitButton.setAttribute("aria-busy", isLoading ? "true" : "false");
    submitButton.innerHTML = isLoading
      ? '<span class="loading-spinner" aria-hidden="true"></span>Sending...'
      : `${SEND_ICON}${defaultSubmitLabel}`;
  };

  const setFieldError = (field, message) => {
    field.error.textContent = message;
    field.input.classList.toggle("is-invalid", Boolean(message));
    field.input.setAttribute("aria-invalid", message ? "true" : "false");
  };

  const validateField = (field) => {
    const value = String(field.input.value || "").trim();
    const error = field.validate(value);
    setFieldError(field, error);
    return !error;
  };

  const validateAllFields = () => {
    let firstInvalidField = null;
    let allValid = true;

    fields.forEach((field) => {
      const isValid = validateField(field);
      if (!isValid) {
        allValid = false;
        if (!firstInvalidField) {
          firstInvalidField = field.input;
        }
      }
    });

    return { allValid, firstInvalidField };
  };

  fields.forEach((field) => {
    field.input.addEventListener("blur", () => {
      validateField(field);
    });
    field.input.addEventListener("input", () => {
      if (field.input.classList.contains("is-invalid")) {
        validateField(field);
      }
    });
  });

  contactForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const validation = validateAllFields();
    if (!validation.allValid) {
      showFormMessage(formMessage, "Please fix the highlighted fields and try again.", "error");
      if (validation.firstInvalidField) {
        validation.firstInvalidField.focus();
      }
      return;
    }

    const formData = new FormData(contactForm);
    const payload = {
      name: String(formData.get("name") || "").trim(),
      email: String(formData.get("email") || "").trim(),
      subject: String(formData.get("subject") || "").trim(),
      message: String(formData.get("message") || "").trim(),
      company: String(formData.get("company") || "").trim(),
    };

    if (payload.company) {
      contactForm.reset();
      fields.forEach((field) => setFieldError(field, ""));
      showFormMessage(formMessage, "Thanks!", "success");
      return;
    }

    setSubmitButtonState(true);

    try {
      const endpoint = contactForm.getAttribute("action") || "/api/contact.php";
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(payload),
      });

      let data = null;
      try {
        data = await response.json();
      } catch (_error) {
        data = null;
      }

      if (!response.ok || !data || data.ok !== true) {
        throw new Error("submit_failed");
      }

      showFormMessage(formMessage, "Message sent successfully. I will get back to you soon.", "success");
      trackEvent("contact_form_submit", { status: "success" });
      contactForm.reset();
      fields.forEach((field) => setFieldError(field, ""));
    } catch (_error) {
      const mailSubject = encodeURIComponent(`[Portfolio] ${payload.subject}`);
      const mailBody = encodeURIComponent(`Name: ${payload.name}\nEmail: ${payload.email}\n\n${payload.message}`);

      window.location.href = `mailto:radmanqelichi@gmail.com?subject=${mailSubject}&body=${mailBody}`;
      showFormMessage(
        formMessage,
        "Could not send directly from the website. Your email app should open now with your message pre-filled.",
        "success"
      );
      trackEvent("contact_form_submit", { status: "mailto_fallback" });
    } finally {
      setSubmitButtonState(false);
    }
  });
}

function showFormMessage(formMessage, message, kind) {
  formMessage.textContent = message;
  formMessage.classList.remove("success", "error");
  formMessage.classList.add(kind, "show");
  formMessage.setAttribute("aria-live", kind === "error" ? "assertive" : "polite");
  if (kind === "error") {
    formMessage.focus();
  }
}

function reserveTypedTextSpace(typedElement, words) {
  if (!words.length) {
    return;
  }

  const probe = document.createElement("span");
  const computedStyle = window.getComputedStyle(typedElement);

  probe.style.position = "absolute";
  probe.style.visibility = "hidden";
  probe.style.pointerEvents = "none";
  probe.style.whiteSpace = "nowrap";
  probe.style.fontFamily = computedStyle.fontFamily;
  probe.style.fontSize = computedStyle.fontSize;
  probe.style.fontWeight = computedStyle.fontWeight;
  probe.style.fontStyle = computedStyle.fontStyle;
  probe.style.letterSpacing = computedStyle.letterSpacing;
  probe.style.textTransform = computedStyle.textTransform;

  document.body.appendChild(probe);

  let maxWordWidth = 0;
  words.forEach((word) => {
    probe.textContent = word;
    maxWordWidth = Math.max(maxWordWidth, probe.getBoundingClientRect().width);
  });

  probe.remove();

  typedElement.style.width = `${Math.ceil(maxWordWidth + 12)}px`;
}

function setupTypedEffect() {
  const typedElement = document.querySelector(".typed-text");

  if (!typedElement) {
    return;
  }

  const words = ["RADIREX", "a Full Stack Dev", "a UI/UX Designer", "a Problem Solver", "a Debugger"];
  let resizeFrame = null;

  reserveTypedTextSpace(typedElement, words);
  window.addEventListener("resize", () => {
    if (resizeFrame !== null) {
      window.cancelAnimationFrame(resizeFrame);
    }
    resizeFrame = window.requestAnimationFrame(() => {
      reserveTypedTextSpace(typedElement, words);
      resizeFrame = null;
    });
  });

  if (prefersReducedMotion || document.documentElement.classList.contains("reduced-effects")) {
    typedElement.textContent = words[0];
    return;
  }

  let wordIndex = 0;
  let charIndex = 0;
  let isDeleting = false;

  const tick = () => {
    if (document.hidden) {
      window.setTimeout(tick, 250);
      return;
    }

    const currentWord = words[wordIndex];
    charIndex += isDeleting ? -1 : 1;
    typedElement.textContent = currentWord.slice(0, charIndex);

    if (!isDeleting && charIndex === currentWord.length) {
      isDeleting = true;
      window.setTimeout(tick, 1200);
      return;
    }

    if (isDeleting && charIndex === 0) {
      isDeleting = false;
      wordIndex = (wordIndex + 1) % words.length;
    }

    const baseDelay = isDeleting ? 40 : 75;
    const jitter = Math.floor(Math.random() * 20);
    window.setTimeout(tick, baseDelay + jitter);
  };

  window.setTimeout(tick, 350);
}
