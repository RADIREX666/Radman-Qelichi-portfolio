#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

bash "$ROOT_DIR/scripts/sync-cloudlinux.sh"

tar -czf "$ROOT_DIR/dist-cloudlinux.tar.gz" -C "$ROOT_DIR" dist-cloudlinux

echo "Created $ROOT_DIR/dist-cloudlinux.tar.gz"
