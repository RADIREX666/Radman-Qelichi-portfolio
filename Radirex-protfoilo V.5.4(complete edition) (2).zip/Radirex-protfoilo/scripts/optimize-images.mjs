import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SOURCE_DIR = path.join(ROOT_DIR, "public", "images", "source");
const OUTPUT_DIR = path.join(ROOT_DIR, "public", "images", "optimized");
const OG_SOURCE = path.join(ROOT_DIR, "public", "og-image-source.png");
const OG_BASENAME = "og-image-1200";
const WIDTHS = [480, 768, 1200];

async function fileExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

async function getImageFiles(dirPath) {
  const exists = await fileExists(dirPath);
  if (!exists) {
    return [];
  }

  const entries = await fs.readdir(dirPath, { withFileTypes: true });
  const files = [];

  for (const entry of entries) {
    const entryPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      files.push(...(await getImageFiles(entryPath)));
      continue;
    }

    if (!/\.(png|jpe?g)$/i.test(entry.name)) {
      continue;
    }
    files.push(entryPath);
  }

  return files;
}

function toPosixPath(filePath) {
  return filePath.split(path.sep).join("/");
}

async function optimizeImageFile(sharp, inputPath, outputDir, manifest, isOg = false) {
  const relativePath = isOg ? OG_BASENAME : path.relative(SOURCE_DIR, inputPath).replace(/\.[^.]+$/, "");
  const outputBaseDir = isOg ? outputDir : path.join(outputDir, path.dirname(relativePath));
  await fs.mkdir(outputBaseDir, { recursive: true });

  const webpSrcset = [];
  const avifSrcset = [];
  const jpegSrcset = [];

  for (const width of WIDTHS) {
    const baseName = isOg ? OG_BASENAME : path.basename(relativePath);
    const outputWebp = path.join(outputBaseDir, `${baseName}-${width}.webp`);
    const outputAvif = path.join(outputBaseDir, `${baseName}-${width}.avif`);
    const outputJpeg = path.join(outputBaseDir, `${baseName}-${width}.jpg`);

    const image = sharp(inputPath).resize({ width, withoutEnlargement: true });
    await image.webp({ quality: 76 }).toFile(outputWebp);
    await image.avif({ quality: 58 }).toFile(outputAvif);
    await image.jpeg({ quality: 82, mozjpeg: true }).toFile(outputJpeg);

    webpSrcset.push(`${toPosixPath(path.relative(path.join(ROOT_DIR, "public"), outputWebp))} ${width}w`);
    avifSrcset.push(`${toPosixPath(path.relative(path.join(ROOT_DIR, "public"), outputAvif))} ${width}w`);
    jpegSrcset.push(`${toPosixPath(path.relative(path.join(ROOT_DIR, "public"), outputJpeg))} ${width}w`);
  }

  const key = isOg ? "og-image" : toPosixPath(relativePath);
  manifest[key] = {
    avif: avifSrcset,
    webp: webpSrcset,
    jpeg: jpegSrcset,
  };
}

async function main() {
  let sharp;
  try {
    ({ default: sharp } = await import("sharp"));
  } catch (_error) {
    console.error("Image optimization requires 'sharp'. Install it with: npm i -D sharp");
    process.exitCode = 1;
    return;
  }

  await fs.mkdir(OUTPUT_DIR, { recursive: true });

  const imageFiles = await getImageFiles(SOURCE_DIR);
  const manifest = {};

  for (const imageFile of imageFiles) {
    await optimizeImageFile(sharp, imageFile, OUTPUT_DIR, manifest);
  }

  if (await fileExists(OG_SOURCE)) {
    await optimizeImageFile(sharp, OG_SOURCE, path.join(ROOT_DIR, "public"), manifest, true);
  } else {
    console.warn("Skipped OG generation: public/og-image-source.png is missing.");
  }

  const manifestPath = path.join(OUTPUT_DIR, "manifest.json");
  await fs.writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");

  console.log(`Optimized ${imageFiles.length} content images.`);
  console.log(`Manifest written to ${toPosixPath(path.relative(ROOT_DIR, manifestPath))}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
