#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT_DIR/dist-cloudlinux"

rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"

cp "$ROOT_DIR/index.html" "$OUT_DIR/index.html"
cp "$ROOT_DIR/style.css" "$OUT_DIR/style.css"
cp "$ROOT_DIR/main.js" "$OUT_DIR/main.js"
cp -r "$ROOT_DIR/public/"* "$OUT_DIR/"
cp "$ROOT_DIR/public/.htaccess" "$OUT_DIR/.htaccess"

echo "CloudLinux directory synced at $OUT_DIR"
