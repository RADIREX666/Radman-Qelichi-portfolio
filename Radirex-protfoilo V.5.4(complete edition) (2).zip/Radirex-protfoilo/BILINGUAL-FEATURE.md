# Bilingual Feature (EN/FA) - Documentation

## 🌐 Overview

Your website now supports **bilingual mode** with English (EN) and Persian/Farsi (FA) languages. Users can switch between languages using the language toggle button.

## ✅ What's Been Implemented

### 1. Language Toggle Button
- **Location**: Fixed position on the right side (below theme toggle)
- **Functionality**: Click to switch between EN and FA
- **Persistence**: Language preference saved in localStorage
- **Visual**: Shows current language option (EN shows when in FA mode, FA shows when in EN mode)

### 2. Translated Sections

**Navigation Menu:**
- Home / خانه
- About / درباره
- Skills / مهارت‌ها
- Projects / پروژه‌ها
- Testimonials / نظرات
- Insights / مقالات
- FAQ / سوالات
- Contact / تماس

**Hero Section:**
- "Available for work" / "آماده برای همکاری"
- "Building digital experiences..." / "ساخت تجربیات دیجیتال..."
- "Book a Call" / "رزرو جلسه"
- "View Case Studies" / "مشاهده پروژه‌ها"
- Stats labels (Years Experience, Projects Done, Happy Clients)

**About Section:**
- Section title: "A bit about me" / "کمی درباره من"
- Full biography with your name in both languages
- Mentions "Radman Qelichi" in EN and "رادمان قلیچی" in FA

**Skills Section:**
- "What I'm good at" / "مهارت‌های من"
- "Tools and technologies..." / "ابزارها و تکنولوژی‌ها..."

**Projects Section:**
- "Stuff I've built" / "پروژه‌های من"
- "Here are some projects..." / "اینجا چند پروژه‌ای هستند..."

**Contact Section:**
- "Let's build something together" / "بیایید با هم چیزی بسازیم"
- "Email me" / "ایمیل بزنید"

**Footer:**
- Navigation / منو
- Connect / ارتباط
- All menu items translated

### 3. RTL Support
- **Direction**: Automatically switches to RTL (right-to-left) in FA mode
- **Text Alignment**: Right-aligned for Persian content
- **Font**: Uses Vazirmatn font family for better Persian readability
- **Layout**: All sections properly adjusted for RTL layout

### 4. Typed Text Animation
- **English**: "Radman Qelichi", "RADIREX", "a Full Stack Dev", "a UI/UX Designer", "a Problem Solver"
- **Persian**: "رادمان قلیچی", "RADIREX", "توسعه‌دهنده فول‌استک", "طراح UI/UX", "حل‌کننده مسائل"

## 🎨 Technical Implementation

### HTML Structure
```html
<!-- Elements with bilingual content use data attributes -->
<h2 data-en="English Text" data-fa="متن فارسی">English Text</h2>
```

### CSS Styling
```css
/* Language toggle button */
.lang-toggle {
  position: fixed;
  top: 150px;
  right: 24px;
  /* ... */
}

/* RTL support */
[lang="fa"] {
  direction: rtl;
  font-family: 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif;
}
```

### JavaScript Functionality
```javascript
// Language toggle initialization
initLanguageToggle();

// Updates all elements with data-en/data-fa attributes
updateLanguage(lang);

// Saves preference to localStorage
localStorage.setItem('language', newLang);
```

## 🚀 How It Works

1. **Page Load**: 
   - Checks localStorage for saved language preference
   - Defaults to English if no preference found
   - Applies language and updates all content

2. **Language Switch**:
   - User clicks language toggle button
   - JavaScript switches HTML lang attribute
   - All elements with data-en/data-fa update automatically
   - Direction changes (LTR ↔ RTL)
   - Preference saved to localStorage

3. **Persistence**:
   - Language choice remembered across sessions
   - Stored in browser's localStorage
   - Automatically applied on next visit

## 📱 User Experience

### English Mode (Default)
- LTR (left-to-right) layout
- English content displayed
- Button shows "FA" (to switch to Persian)
- Standard Western layout

### Persian Mode
- RTL (right-to-left) layout
- Persian content displayed
- Button shows "EN" (to switch to English)
- Proper Persian typography and spacing
- Your name appears as "رادمان قلیچی"

## 🎯 SEO Benefits

### Bilingual SEO Advantages:
1. **Broader Reach**: Targets both English and Persian-speaking audiences
2. **Name Recognition**: Your name appears in both scripts
   - English: "Radman Qelichi"
   - Persian: "رادمان قلیچی"
3. **Local SEO**: Persian content helps with Iranian search queries
4. **Language Targeting**: Google recognizes lang attribute for proper indexing

### Search Visibility:
- English searches: "Radman Qelichi", "RADIREX full stack developer"
- Persian searches: "رادمان قلیچی", "توسعه دهنده فول استک"
- Both languages indexed by search engines

## 🔧 Customization Guide

### Adding New Translations

1. **Find the element** you want to translate in `index.html`
2. **Add data attributes**:
   ```html
   <p data-en="English text" data-fa="متن فارسی">English text</p>
   ```
3. **Rebuild** the site:
   ```bash
   npm run build
   ```

### Updating Typed Text Words

Edit `main.js` around line 950:
```javascript
const wordsEn = ["Radman Qelichi", "RADIREX", "a Full Stack Dev", ...];
const wordsFa = ["رادمان قلیچی", "RADIREX", "توسعه‌دهنده فول‌استک", ...];
```

### Changing Button Position

Edit `style.css`:
```css
.lang-toggle {
  top: 150px;  /* Adjust vertical position */
  right: 24px; /* Adjust horizontal position */
}
```

## 📊 Browser Compatibility

- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)
- ✅ localStorage supported in all modern browsers

## 🐛 Troubleshooting

### Language not switching?
- Check browser console for JavaScript errors
- Ensure localStorage is enabled
- Clear browser cache and reload

### Persian text not displaying correctly?
- Ensure proper font is loaded (Vazirmatn)
- Check RTL CSS rules are applied
- Verify HTML lang attribute changes

### Button not visible?
- Check z-index conflicts
- Ensure button is not hidden by other elements
- Verify CSS is loaded correctly

## 📈 Analytics Tracking

To track language usage, you can add to Plausible:
```javascript
// Track language switches
plausible('Language Switch', {props: {language: newLang}});
```

## 🎓 Best Practices

1. **Keep translations accurate**: Use native Persian speakers for review
2. **Test both layouts**: Ensure RTL layout works properly
3. **Maintain consistency**: Use same terminology across all pages
4. **Update both languages**: When adding content, translate immediately
5. **Consider cultural context**: Some phrases may need cultural adaptation

## 🚀 Future Enhancements

Potential improvements:
- [ ] Add more languages (Arabic, Turkish, etc.)
- [ ] Translate blog posts and case studies
- [ ] Add language selector in footer
- [ ] Implement URL-based language switching (/en/, /fa/)
- [ ] Add language meta tags for better SEO
- [ ] Create separate sitemaps for each language

## 📞 Summary

Your website now offers a **seamless bilingual experience** that:
- Switches between English and Persian instantly
- Maintains user preference across sessions
- Properly handles RTL layout for Persian
- Displays your name in both scripts for better SEO
- Provides professional localization for Iranian market

**The bilingual feature is live and ready to use!** 🎉

---

*Last updated: 2026-04-28*
*Feature implemented by: RADIREX Development*
