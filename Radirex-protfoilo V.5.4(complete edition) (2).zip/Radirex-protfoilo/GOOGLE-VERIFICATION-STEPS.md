# Google Search Console Verification Steps

## Step 1: Access Google Search Console
1. Go to: https://search.google.com/search-console
2. Sign in with your Google account
3. Click "Add Property"
4. Choose "URL prefix" and enter: https://radirex.ir

## Step 2: Verify Ownership (Choose ONE method)

### Method A: HTML File Upload (RECOMMENDED - Easiest)
1. Google will give you a file like: `google1234567890abcdef.html`
2. Download that file
3. Upload it to your website root: `public/google1234567890abcdef.html`
4. Make sure it's accessible at: `https://radirex.ir/google1234567890abcdef.html`
5. Click "Verify" in Google Search Console

### Method B: HTML Meta Tag
1. Google will give you a meta tag like:
   ```html
   <meta name="google-site-verification" content="1234567890abcdef" />
   ```
2. Add this to the `<head>` section of your `index.html`
3. Deploy your site
4. Click "Verify" in Google Search Console

### Method C: DNS Verification (If you manage DNS)
1. Google will give you a TXT record
2. Add it to your domain's DNS settings
3. Wait for DNS propagation (can take 24-48 hours)
4. Click "Verify"

## Step 3: Submit Sitemap
1. After verification, go to "Sitemaps" in the left menu
2. Enter: `sitemap.xml`
3. Click "Submit"
4. Your sitemap URL will be: https://radirex.ir/sitemap.xml

## Step 4: Request Indexing
1. Go to "URL Inspection" tool
2. Enter: https://radirex.ir
3. Click "Request Indexing"
4. Repeat for important pages:
   - https://radirex.ir/insights/
   - https://radirex.ir/case-studies/

## Step 5: Monitor Performance
- Check "Performance" tab after 2-3 days
- Monitor impressions, clicks, CTR
- Track keyword rankings

## Expected Timeline
- Verification: Immediate
- First data in Search Console: 2-3 days
- Full indexing: 1-2 weeks
- Ranking improvements: 2-4 weeks

## Troubleshooting
- If verification fails, check file is accessible
- Clear browser cache and try again
- Make sure robots.txt allows Googlebot
- Check HTTPS certificate is valid
