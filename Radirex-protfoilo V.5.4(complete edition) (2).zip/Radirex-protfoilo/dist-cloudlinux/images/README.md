Image Optimization Pipeline

1) Put source images in `public/images/source/` as `.png`, `.jpg`, or `.jpeg`.
2) Put the social card source at `public/og-image-source.png` (recommended 1200x630).
3) Run:

```bash
npm run images:optimize
```

What it generates
- Responsive image variants in `public/images/optimized/` as AVIF, WebP, and JPEG.
- OG card variants in `public/` as:
  - `og-image-1200-480.avif/.webp/.jpg`
  - `og-image-1200-768.avif/.webp/.jpg`
  - `og-image-1200-1200.avif/.webp/.jpg`
- A manifest at `public/images/optimized/manifest.json` with ready-to-use `srcset` values.

Example markup

```html
<picture>
  <source type="image/avif" srcset="/images/optimized/example-480.avif 480w, /images/optimized/example-768.avif 768w, /images/optimized/example-1200.avif 1200w" sizes="(max-width: 768px) 100vw, 50vw">
  <source type="image/webp" srcset="/images/optimized/example-480.webp 480w, /images/optimized/example-768.webp 768w, /images/optimized/example-1200.webp 1200w" sizes="(max-width: 768px) 100vw, 50vw">
  <img src="/images/optimized/example-768.jpg" width="768" height="432" loading="lazy" decoding="async" alt="">
</picture>
```
