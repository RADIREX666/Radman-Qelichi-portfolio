<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed']);
    exit;
}

$rawInput = file_get_contents('php://input');
$payload = [];

if (is_string($rawInput) && trim($rawInput) !== '') {
    $decoded = json_decode($rawInput, true);
    if (is_array($decoded)) {
        $payload = $decoded;
    }
}

if (empty($payload)) {
    $payload = $_POST;
}

$name = trim((string)($payload['name'] ?? ''));
$email = trim((string)($payload['email'] ?? ''));
$subject = trim((string)($payload['subject'] ?? ''));
$message = trim((string)($payload['message'] ?? ''));
$company = trim((string)($payload['company'] ?? ''));

if ($company !== '') {
    // Honeypot: silently accept.
    echo json_encode(['ok' => true]);
    exit;
}

if ($name === '' || $email === '' || $subject === '' || $message === '') {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Missing required fields']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'message' => 'Invalid email']);
    exit;
}

$safeSubject = preg_replace('/[\r\n]+/', ' ', $subject);
$safeName = preg_replace('/[\r\n]+/', ' ', $name);
$safeEmail = preg_replace('/[\r\n]+/', '', $email);

$to = 'radmanqelichi@gmail.com';
$mailSubject = '[Portfolio Contact] ' . $safeSubject;
$mailBody = "Name: {$safeName}\n";
$mailBody .= "Email: {$safeEmail}\n\n";
$mailBody .= $message . "\n";
$mailBody .= "\n---\nSent from radirex.ir contact form\n";

$headers = [];
$headers[] = 'From: RADIREX Portfolio <no-reply@radirex.ir>';
$headers[] = 'Reply-To: ' . $safeEmail;
$headers[] = 'Content-Type: text/plain; charset=UTF-8';

$sent = @mail($to, $mailSubject, $mailBody, implode("\r\n", $headers));

if (!$sent) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Mail delivery failed']);
    exit;
}

echo json_encode(['ok' => true]);
