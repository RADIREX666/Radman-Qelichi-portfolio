(() => {
  const path = window.location.pathname;
  const isInsightsIndex = path.endsWith("/insights/") || path.endsWith("/insights/index.html");
  const isInsightsPage = path.includes("/insights/");
  const isInsightsArticle = isInsightsPage && !isInsightsIndex;

  const originalMainHTML = (() => {
    const main = document.querySelector("main.container");
    return main ? main.innerHTML : "";
  })();

  const words = {
    en: {
      backHome: "← Back to Home",
      backInsights: "← Back to Insights",
      contact: "Work with Radman Qelichi",
      startProject: "Start a Project",
      langLabel: "Switch language",
      themeLabel: "Toggle theme",
      indexTitle: "Radman Qelichi Insights",
      indexBadge: "Insights",
      indexHero: "Performance, architecture, and SEO guides",
      indexMeta: "Updated 2026-04-24 | Built for high-intent traffic and qualified lead generation.",
      indexRead: "Read article",
      articleFallbackTitle: "Insights article",
    },
    fa: {
      backHome: "بازگشت به خانه",
      backInsights: "بازگشت به راهنماها",
      contact: "همکاری با رادمان قلیچی",
      startProject: "شروع پروژه",
      langLabel: "تغییر زبان",
      themeLabel: "تغییر تم",
      indexTitle: "راهنماهای رادمان قلیچی",
      indexBadge: "راهنماها",
      indexHero: "راهنماهای عملکرد، معماری و سئو",
      indexMeta: "به‌روزرسانی: ۲۰۲۶-۰۴-۲۴ | مناسب برای جذب کاربر هدفمند و رشد ورودی باکیفیت",
      indexRead: "مطالعه راهنما",
      articleFallbackTitle: "نسخه فارسی این راهنما",
    },
  };

  const insightsIndexData = {
    en: {
      titles: [
        "Web Developer in Iran: Hiring Guide for Product Teams",
        "React Performance Optimization: Practical Playbook",
        "Python Backend Architecture for Scalable Products",
        "CloudLinux Deployment Checklist for Production Reliability",
        "How to Hire a Freelance Full-Stack Developer in Iran",
        "Technical SEO for JavaScript Websites",
      ],
      descriptions: [
        "How to hire a web developer in Iran with clear scope, milestone planning, and quality checks that protect delivery speed.",
        "A practical React performance optimization checklist to improve LCP, INP, and CLS in real production apps.",
        "A Python backend architecture guide covering API design, data modeling, caching, background jobs, and observability.",
        "CloudLinux deployment checklist covering security headers, caching, release workflow, and post-deploy verification.",
        "A full-stack developer hiring playbook for Iranian and global teams: interviews, milestones, and quality controls.",
        "Technical SEO checklist for JavaScript websites: crawlability, metadata, performance budgets, and structured data basics.",
      ],
    },
    fa: {
      titles: [
        "توسعه‌دهنده وب در ایران: راهنمای استخدام برای تیم‌های محصول",
        "بهینه‌سازی عملکرد ری‌اکت: راهنمای کاربردی",
        "معماری بک‌اند پایتون برای محصولات مقیاس‌پذیر",
        "چک‌لیست استقرار کلادلینوکس برای پایداری در پروداکشن",
        "چطور یک توسعه‌دهنده فول‌استک فریلنس در ایران استخدام کنیم",
        "سئوی فنی برای وب‌سایت‌های جاوااسکریپت",
      ],
      descriptions: [
        "راهنمای عملی استخدام توسعه‌دهنده وب در ایران با محدوده کاری شفاف، برنامه‌ریزی مایلستون و کنترل کیفیت.",
        "یک چک‌لیست کاربردی برای بهبود شاخص‌های سرعت و پایداری در اپلیکیشن‌های واقعی ری‌اکت.",
        "راهنمای معماری بک‌اند پایتون شامل طراحی رابط برنامه‌نویسی، مدل‌سازی داده، کش، پردازش پس‌زمینه و مانیتورینگ.",
        "چک‌لیست استقرار کلادلینوکس شامل هدرهای امنیتی، کش، روند انتشار و بررسی‌های پس از انتشار.",
        "یک پلن استخدام توسعه‌دهنده فول‌استک برای تیم‌های ایرانی و بین‌المللی با معیارهای کیفیت و تحویل.",
        "چک‌لیست سئوی فنی برای وب‌سایت‌های جاوااسکریپت: خزش‌پذیری، متادیتا، بودجه عملکرد و داده ساختاریافته.",
      ],
    },
  };

  const setTheme = (theme) => {
    const finalTheme = theme === "light" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", finalTheme);
    document.documentElement.style.colorScheme = finalTheme;
    localStorage.setItem("theme", finalTheme);

    const themeButton = document.getElementById("insightsThemeToggle");
    if (themeButton) {
      themeButton.textContent = finalTheme === "dark" ? "☀" : "☾";
    }
  };

  const addHeaderControls = () => {
    const topbar = document.querySelector(".topbar");
    if (!topbar || document.getElementById("insightsLangToggle")) {
      return;
    }

    const controls = document.createElement("div");
    controls.className = "topbar-controls";
    controls.innerHTML = `
      <button id="insightsLangToggle" class="lang-switch" type="button" aria-label="Switch language">
        <span class="lang-option" data-set-lang="fa">FA</span>
        <span class="lang-divider" aria-hidden="true">|</span>
        <span class="lang-option" data-set-lang="en">EN</span>
      </button>
      <button id="insightsThemeToggle" class="theme-switch" type="button" aria-label="Toggle theme">☀</button>
    `;
    topbar.appendChild(controls);
  };

  const applyTopbarLanguage = (lang) => {
    const isFa = lang === "fa";
    const entries = document.querySelectorAll(".topbar a");
    const left = entries[0];
    const right = entries[1];

    if (left) {
      left.textContent = isInsightsIndex ? (isFa ? words.fa.backHome : words.en.backHome) : (isFa ? words.fa.backInsights : words.en.backInsights);
    }

    if (right) {
      right.textContent = isInsightsIndex ? (isFa ? words.fa.contact : words.en.contact) : (isFa ? words.fa.startProject : words.en.startProject);
    }

    const langToggle = document.getElementById("insightsLangToggle");
    if (langToggle) {
      langToggle.setAttribute("aria-label", isFa ? words.fa.langLabel : words.en.langLabel);
      langToggle.querySelectorAll(".lang-option").forEach((node) => {
        node.classList.toggle("is-active", node.getAttribute("data-set-lang") === lang);
      });
    }

    const themeButton = document.getElementById("insightsThemeToggle");
    if (themeButton) {
      themeButton.setAttribute("aria-label", isFa ? words.fa.themeLabel : words.en.themeLabel);
    }
  };

  const applyIndexLanguage = (lang) => {
    const isFa = lang === "fa";
    const text = words[lang];
    const data = insightsIndexData[lang];

    document.title = text.indexTitle;
    const badge = document.querySelector(".hero .badge");
    const heroTitle = document.querySelector(".hero h1");
    const heroMeta = document.querySelector(".hero .meta");
    if (badge) badge.textContent = text.indexBadge;
    if (heroTitle) heroTitle.textContent = text.indexHero;
    if (heroMeta) heroMeta.textContent = text.indexMeta;

    const cards = document.querySelectorAll(".content .card");
    cards.forEach((card, index) => {
      const title = card.querySelector("h2 a");
      const description = card.querySelector("p");
      const cta = card.querySelector(".cta");

      if (title) title.textContent = data.titles[index] || title.textContent;
      if (description) description.textContent = data.descriptions[index] || description.textContent;
      if (cta) cta.textContent = text.indexRead;
    });

    document.documentElement.setAttribute("dir", isFa ? "rtl" : "ltr");
    document.body.style.direction = isFa ? "rtl" : "ltr";
  };

  const applyArticleLanguage = (lang) => {
    const main = document.querySelector("main.container");
    if (!main) {
      return;
    }

    if (lang === "fa") {
      document.title = words.fa.articleFallbackTitle;
      main.innerHTML = `
        <section class="hero">
          <span class="badge">راهنما</span>
          <h1>نسخه فارسی راهنمای کامل به‌زودی منتشر می‌شود</h1>
          <p class="meta">برای جلوگیری از نمایش متن انگلیسی، نسخه موقت فارسی نمایش داده شده است.</p>
        </section>
        <section class="content" style="grid-template-columns:1fr;">
          <div>
            <article class="card">
              <h2>خلاصه</h2>
              <p>در حال آماده‌سازی نسخه فارسی کامل این مقاله هستم تا هیچ متن انگلیسی در حالت فارسی نمایش داده نشود.</p>
              <p>تا زمان انتشار، می‌توانید از لیست راهنماها یا فرم تماس استفاده کنید.</p>
              <a class="cta" href="/insights/index.html">مشاهده همه راهنماها</a>
            </article>
          </div>
        </section>
      `;
      document.documentElement.setAttribute("dir", "rtl");
      document.body.style.direction = "rtl";
      return;
    }

    main.innerHTML = originalMainHTML;
    document.title = document.querySelector("meta[property='og:title']")?.getAttribute("content") || "Radman Qelichi Insights";
    document.documentElement.setAttribute("dir", "ltr");
    document.body.style.direction = "ltr";
  };

  const applyLanguage = (lang) => {
    const finalLang = lang === "fa" ? "fa" : "en";
    document.documentElement.setAttribute("lang", finalLang);
    localStorage.setItem("language", finalLang);

    applyTopbarLanguage(finalLang);

    if (isInsightsIndex) {
      applyIndexLanguage(finalLang);
    } else if (isInsightsArticle) {
      applyArticleLanguage(finalLang);
      applyTopbarLanguage(finalLang);
    }
  };

  const setupLanguageToggle = () => {
    const langToggle = document.getElementById("insightsLangToggle");
    if (!langToggle) return;

    langToggle.addEventListener("click", (event) => {
      const target = event.target instanceof HTMLElement ? event.target.closest("[data-set-lang]") : null;
      if (target instanceof HTMLElement) {
        applyLanguage(target.getAttribute("data-set-lang") || "en");
        return;
      }

      const current = document.documentElement.getAttribute("lang") === "fa" ? "fa" : "en";
      applyLanguage(current === "fa" ? "en" : "fa");
    });
  };

  const setupThemeToggle = () => {
    const themeButton = document.getElementById("insightsThemeToggle");
    if (!themeButton) return;

    themeButton.addEventListener("click", () => {
      const current = document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
      setTheme(current === "light" ? "dark" : "light");
    });

    setTheme(document.documentElement.getAttribute("data-theme") || "dark");
  };

  const setupLinkPrefetch = () => {
    const visited = new Set();

    const prefetch = (href) => {
      if (!href || visited.has(href)) return;
      visited.add(href);

      const hint = document.createElement("link");
      hint.rel = "prefetch";
      hint.href = href;
      hint.as = "document";
      document.head.appendChild(hint);
    };

    document.querySelectorAll('a[href^="/"]').forEach((link) => {
      if (!(link instanceof HTMLAnchorElement)) return;
      const href = link.getAttribute("href");
      if (!href || (!href.includes("/insights/") && !href.includes("/index.html"))) return;

      const warm = () => prefetch(href);
      link.addEventListener("pointerenter", warm, { once: true });
      link.addEventListener("focus", warm, { once: true });
      link.addEventListener("touchstart", warm, { once: true, passive: true });
    });
  };

  addHeaderControls();
  setupLanguageToggle();
  setupThemeToggle();
  setupLinkPrefetch();
  applyLanguage(localStorage.getItem("language") || "en");
})();
